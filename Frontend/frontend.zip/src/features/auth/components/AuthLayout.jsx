import ThemeToggle from "../../../shared/components/ThemeToggle";
import { useTheme } from "../../../shared/hooks/useTheme";
import "./AuthLayout.scss";

const VALUE_POINTS = [
  {
    title: "Deep Semantic Reconciliation",
    desc: "Analyzes every nuance of your resume against target requirements and seniority expectations.",
    icon: (
      <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <path d="M10 2.5a7.5 7.5 0 100 15 7.5 7.5 0 000-15z" stroke="currentColor" strokeWidth="1.5" />
        <path d="M10 6v4l2.5 2.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    title: "Predictive Interview Angles",
    desc: "Uncovers high-probability technical, architectural, and situational questions tailored to the stack.",
    icon: (
      <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <path
          d="M7.5 16.5h5M10 14V16.5M14.5 7.5a4.5 4.5 0 10-9 0c0 2 1.5 3.5 2.5 4.5h4c1-1 2.5-2.5 2.5-4.5z"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
  {
    title: "Tactical 7-Day Sprint",
    desc: "Generates a structured, paced preparation protocol to systematically close identified gaps.",
    icon: (
      <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <path
          d="M3.5 5.5A1.5 1.5 0 015 4h10a1.5 1.5 0 011.5 1.5v10a1.5 1.5 0 01-1.5 1.5H5a1.5 1.5 0 01-1.5-1.5v-10z"
          stroke="currentColor"
          strokeWidth="1.5"
        />
        <path d="M3.5 8.5h13M7.5 2.5v3M12.5 2.5v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        <path d="M7 12l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
];

const AuthLayout = ({ eyebrow, title, subtitle, children }) => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="auth-layout">
      {/* Left Column: Abstract Futuristic Design Showcase */}
      <aside className="auth-layout__brand" aria-label="Brand Overview">
        {/* Animated Background Visual Elements */}
        <div className="auth-layout__bg-art" aria-hidden="true">
          <div className="auth-layout__orb auth-layout__orb--primary" />
          <div className="auth-layout__orb auth-layout__orb--cyan" />
          <div className="auth-layout__grid-mesh" />
        </div>

        <div className="auth-layout__brand-top">
          <div className="auth-layout__brand-logo">
            <div className="auth-layout__mark" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div className="auth-layout__logo-text">
              <span className="auth-layout__wordmark">Resume Analyzer</span>
              <span className="auth-layout__tagline">Interview Studio</span>
            </div>
          </div>
          <div className="auth-layout__live-indicator">
            <span className="auth-layout__live-dot" />
            <span>AI Neural Core v2.4</span>
          </div>
        </div>

        <div className="auth-layout__hero">
          <div className="glow-pill auth-layout__hero-pill">
            <span className="glow-pill__dot" />
            <span>AI INTERVIEW READINESS</span>
          </div>
          <h2 className="auth-layout__headline">
            Precision Intelligence for <span className="gradient-text-neon">Every Technical Interview</span>.
          </h2>
          <p className="auth-layout__sub">
            Bridging the gap between candidate qualifications and role requirements with deep
            semantic synthesis, automated skill gap audits, and structured preparation roadmaps.
          </p>
        </div>

        {/* Abstract Geometric Design Feature Visual */}
        <div className="auth-layout__graphic" aria-hidden="true">
          <div className="auth-graphic-card glass-panel">
            <div className="auth-graphic-card__glow" />
            <div className="auth-graphic-card__header">
              <div className="auth-graphic-card__dots">
                <span className="auth-graphic-card__dot auth-graphic-card__dot--red" />
                <span className="auth-graphic-card__dot auth-graphic-card__dot--yellow" />
                <span className="auth-graphic-card__dot auth-graphic-card__dot--green" />
              </div>
              <span className="auth-graphic-card__label">RECON ENGINE // ACTIVE</span>
            </div>

            <div className="auth-graphic-card__body">
              <svg viewBox="0 0 400 130" fill="none" className="auth-graphic-card__svg">
                <defs>
                  <linearGradient id="neuralLine" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity="0.8" />
                    <stop offset="50%" stopColor="#06b6d4" stopOpacity="1" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.8" />
                  </linearGradient>
                  <linearGradient id="glowGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid guidelines */}
                <line x1="20" y1="20" x2="380" y2="20" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                <line x1="20" y1="65" x2="380" y2="65" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                <line x1="20" y1="110" x2="380" y2="110" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />

                {/* Graph Fill and Line */}
                <path
                  d="M20 95 Q 80 40, 140 70 T 260 30 T 380 45 L 380 120 L 20 120 Z"
                  fill="url(#glowGrad)"
                />
                <path
                  d="M20 95 Q 80 40, 140 70 T 260 30 T 380 45"
                  stroke="url(#neuralLine)"
                  strokeWidth="3"
                  strokeLinecap="round"
                />

                {/* Nodes */}
                <circle cx="20" cy="95" r="4" fill="#6366f1" stroke="#ffffff" strokeWidth="1.5" />
                <circle cx="140" cy="70" r="4" fill="#818cf8" stroke="#ffffff" strokeWidth="1.5" />
                <circle cx="260" cy="30" r="5" fill="#06b6d4" stroke="#ffffff" strokeWidth="2" />
                <circle cx="380" cy="45" r="4" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
              </svg>

              <div className="auth-graphic-card__tags">
                <span className="auth-graphic-card__tag">
                  <span className="auth-graphic-card__tag-dot" /> Multi-Vector Parsing
                </span>
                <span className="auth-graphic-card__tag">
                  <span className="auth-graphic-card__tag-dot auth-graphic-card__tag-dot--cyan" /> Deep Context Alignment
                </span>
                <span className="auth-graphic-card__tag">
                  <span className="auth-graphic-card__tag-dot auth-graphic-card__tag-dot--emerald" /> Real-time Synthesis
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Value Points */}
        <div className="auth-layout__points">
          {VALUE_POINTS.map((pt, idx) => (
            <div key={idx} className="auth-layout__point">
              <span className="auth-layout__point-icon" aria-hidden="true">
                {pt.icon}
              </span>
              <div className="auth-layout__point-text">
                <span className="auth-layout__point-title">{pt.title}</span>
                <span className="auth-layout__point-desc">{pt.desc}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Metrics */}
        <div className="auth-layout__brand-foot">
          <div className="auth-layout__metric">
            <span className="auth-layout__metric-value">100%</span>
            <span className="auth-layout__metric-label">Private &amp; Confidential</span>
          </div>
          <div className="auth-layout__metric-divider" />
          <div className="auth-layout__metric">
            <span className="auth-layout__metric-value">&lt; 15s</span>
            <span className="auth-layout__metric-label">AI Neural Speed</span>
          </div>
          <div className="auth-layout__metric-divider" />
          <div className="auth-layout__metric">
            <span className="auth-layout__metric-value">PDF</span>
            <span className="auth-layout__metric-label">Export Ready</span>
          </div>
        </div>
      </aside>

      {/* Right Column: Clean Form Container */}
      <main className="auth-layout__panel">
        <header className="auth-layout__panel-top">
          <div className="auth-layout__mobile-brand">
            <div className="auth-layout__mark auth-layout__mark--sm" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div className="auth-layout__logo-text">
              <span className="auth-layout__wordmark">Resume Analyzer</span>
              <span className="auth-layout__tagline">Studio</span>
            </div>
          </div>
          <div className="auth-layout__panel-actions">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </div>
        </header>

        <div className="auth-layout__form-wrap">
          <div className="auth-layout__form-header">
            {eyebrow && <span className="eyebrow auth-layout__eyebrow">{eyebrow}</span>}
            <h1 className="auth-layout__title">{title}</h1>
            {subtitle && <p className="auth-layout__form-desc">{subtitle}</p>}
          </div>

          <div className="auth-layout__form-card glass-panel">
            {children}
          </div>

          <p className="auth-layout__secure-note">
            <svg viewBox="0 0 16 16" fill="none" className="auth-layout__secure-icon" aria-hidden="true">
              <rect x="3" y="6" width="10" height="8" rx="2" stroke="currentColor" strokeWidth="1.3" />
              <path d="M5 6V4a3 3 0 0 1 6 0v2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
            </svg>
            <span>Your resume is encrypted &amp; never retained for model training</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default AuthLayout;

