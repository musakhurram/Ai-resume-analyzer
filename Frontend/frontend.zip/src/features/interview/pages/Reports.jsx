import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router";
import { listReports } from "../services/interview.api";
import ReportCard from "../components/ReportCard";
import PageLoader from "../../../shared/components/PageLoader";
import EmptyState from "../../../shared/components/EmptyState";
import Callout from "../../../shared/components/Callout";
import Button from "../../../shared/components/Button";
import { parseJobMeta } from "../../../shared/utils/jobText";
import "./Reports.scss";

const Reports = () => {
  const [reports, setReports] = useState(null);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    let cancelled = false;
    listReports()
      .then((data) => {
        if (!cancelled) setReports(data.reports || []);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err.response?.data?.message || err.message || "Couldn't load reports.");
          setReports([]);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const stats = useMemo(() => {
    if (!reports || !reports.length) return null;
    const count = reports.length;
    const scores = reports.map((r) => r.matchScore || 0);
    const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / count);
    const maxScore = Math.max(...scores);
    return { count, avgScore, maxScore };
  }, [reports]);

  const filteredReports = useMemo(() => {
    if (!reports) return [];
    let list = [...reports];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter((r) => {
        const meta = parseJobMeta(r.jobDescription);
        const titleMatch = meta.title.toLowerCase().includes(q);
        const compMatch = meta.company?.toLowerCase().includes(q);
        const textMatch = r.jobDescription?.toLowerCase().includes(q);
        return titleMatch || compMatch || textMatch;
      });
    }

    if (sortBy === "highest") {
      list.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
    } else if (sortBy === "lowest") {
      list.sort((a, b) => (a.matchScore || 0) - (b.matchScore || 0));
    } else {
      // newest
      list.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    }

    return list;
  }, [reports, searchQuery, sortBy]);

  if (reports === null) {
    return <PageLoader label="Pulling your intelligence archive" />;
  }

  return (
    <div className="reports-page">
      <header className="page-header">
        <div className="glow-pill">
          <span className="glow-pill__dot" />
          <span>INTELLIGENCE REPOSITORY</span>
        </div>
        <h1 className="reports-page__title">Archived Dossiers</h1>
        <p className="page-header__desc">
          Review past candidate-to-job reconciliations, examine historical match ratings, and download PDF briefing reports.
        </p>
      </header>

      {error && <Callout tone="error" title="Archive Access Error">{error}</Callout>}

      {/* Stats Overview HUD */}
      {stats && (
        <div className="reports-page__stats glass-panel">
          <div className="reports-page__stat-box">
            <span className="reports-page__stat-num gradient-text-neon">{stats.count}</span>
            <span className="reports-page__stat-title">Synthesized Dossiers</span>
          </div>
          <div className="reports-page__stat-divider" />
          <div className="reports-page__stat-box">
            <span className="reports-page__stat-num gradient-text-neon">{stats.avgScore}%</span>
            <span className="reports-page__stat-title">Mean Compatibility</span>
          </div>
          <div className="reports-page__stat-divider" />
          <div className="reports-page__stat-box">
            <span className="reports-page__stat-num gradient-text-neon">{stats.maxScore}%</span>
            <span className="reports-page__stat-title">Peak Fit Benchmark</span>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      {reports.length > 0 && (
        <div className="reports-page__toolbar glass-panel">
          <div className="reports-page__search-wrap">
            <svg viewBox="0 0 16 16" fill="none" className="reports-page__search-icon" aria-hidden="true">
              <path
                d="M7 12A5 5 0 1 0 7 2a5 5 0 0 0 0 10zM14 14l-3.5-3.5"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <input
              type="text"
              placeholder="Search by job title, stack, or company…"
              className="reports-page__search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                type="button"
                className="reports-page__clear-btn"
                onClick={() => setSearchQuery("")}
              >
                Clear
              </button>
            )}
          </div>

          <div className="reports-page__sort-wrap">
            <label htmlFor="sortSelect" className="reports-page__sort-label">Sort:</label>
            <select
              id="sortSelect"
              className="reports-page__sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="newest">Most Recent</option>
              <option value="highest">Highest Score</option>
              <option value="lowest">Lowest Score</option>
            </select>
          </div>
        </div>
      )}

      {reports.length === 0 ? (
        <EmptyState
          eyebrow="No Dossiers Synthesized"
          title="Your intelligence portfolio is empty"
          description="Evaluate your resume against your first target job description to build a comprehensive interview dossier."
          action={
            <Button as={Link} to="/new" variant="primary">
              Launch First Review
            </Button>
          }
        />
      ) : filteredReports.length === 0 ? (
        <EmptyState
          eyebrow="No Matches Found"
          title="No dossiers match your search"
          description="Try modifying your keyword query or resetting your search filter."
          action={
            <Button onClick={() => setSearchQuery("")} variant="secondary">
              Reset Filters
            </Button>
          }
        />
      ) : (
        <div className="reports-page__list">
          {filteredReports.map((report) => (
            <ReportCard key={report._id} report={report} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Reports;

